create function insert_into_usager_projet() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Insert into Usager_projet with cip_createur as cip_Usager
INSERT INTO app.Usager_projet (cip_Usager, Id_projet, admin)
VALUES (NEW.cip_createur, NEW.Id_projet, TRUE);
RETURN NEW;
END;
$$;

alter function insert_into_usager_projet() owner to postgres;

